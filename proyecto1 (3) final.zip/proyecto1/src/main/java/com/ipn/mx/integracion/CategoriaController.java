package com.ipn.mx.integracion;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ipn.mx.modelo.entidades.Articulo;
import com.ipn.mx.modelo.entidades.Categoria;
import com.ipn.mx.servicios.CategoriasService;

@CrossOrigin(origins = {"*"})
@RestController
@RequestMapping("/apiCategoria")
public class CategoriaController {
	@Autowired
	CategoriasService categoriaService;
	
	@GetMapping("/categorias")
	public List<Categoria> encontrarTodas(){
		return categoriaService.findAll();
	}
	
	@GetMapping("/categorias/{id}")
	public Categoria encontrarPorId(@PathVariable Long id){
		return categoriaService.findById(id);
	}
	
	@DeleteMapping("/categorias/{id}")
	public void eliminar(@PathVariable Long id){
		categoriaService.deleteById(id);
	}
	
	@PostMapping("/categorias")
	public Categoria guardar(@RequestBody Categoria categoria){
		return categoriaService.save(categoria);
	}
	
	@PutMapping("/categorias/{id}")
	public Categoria guardar(@PathVariable Long id, @RequestBody Categoria categoria){
		categoria.setIdCategoria(id);
		return categoriaService.update(categoria);
	}

}
