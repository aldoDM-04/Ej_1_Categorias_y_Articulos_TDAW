package com.ipn.mx.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ipn.mx.modelo.entidades.Articulo;
import com.ipn.mx.modelo.repositorios.ArticuloRepositorio;

@Service
public class ArticulosServiceImpl implements ArticulosService{
	
	@Autowired
	ArticuloRepositorio repository;

	@Override
	@Transactional(readOnly=true)
	public List<Articulo> findAll() {
		return (List<Articulo>) repository.findAll();
	}

	@Override
	public Articulo findById(Long id) {
		return repository.findById(id).orElse(null);
	}

	@Override
	public void delete(Long id) {
		repository.deleteById(id);
	}

	@Override
	public Articulo save(Articulo articulo) {
		return repository.save(articulo);
	}
	
	@Override
	public Articulo update(Articulo articulo) {
		return repository.save(articulo);
	}

}
