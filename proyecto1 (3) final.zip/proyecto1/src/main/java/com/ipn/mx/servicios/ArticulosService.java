package com.ipn.mx.servicios;

import java.util.List;

import com.ipn.mx.modelo.entidades.Articulo;

public interface ArticulosService {
	public List<Articulo> findAll();
	public Articulo findById(Long id);
	public void delete(Long id);
	public Articulo save(Articulo articulo);
	public Articulo update(Articulo articulo);

}
