package com.ipn.mx.modelo.entidades;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name ="Articulo")
public class Articulo implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long idArticulo;
	
	@Column(name="nombreArticulo",
			length=50, nullable=false)
	private String nombreArticulo;
	
	@NotBlank(message="La descripcion es obligatoria")
	@Size(min=5,max=250, message="Debe estar entre 5 y 250")
	@Column(name="descripcion",
			length=250, nullable=false)
	private String descripcion;
	
	@Column(name="existencia")
	private int existencia;
	
	@Column(name="precio")
	private double precio;
	
	@JsonIgnoreProperties(value={"listaArticulo","hibernateLazyInitializer","handler"}, allowSetters=true)
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="idCategoria",referencedColumnName="idCategoria")
	private Categoria idCategoria;
	
	

}
