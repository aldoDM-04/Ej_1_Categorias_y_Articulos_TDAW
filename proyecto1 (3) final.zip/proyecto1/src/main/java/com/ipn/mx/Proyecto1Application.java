package com.ipn.mx;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.ipn.mx.modelo.entidades.Categoria;
import com.ipn.mx.modelo.repositorios.CategoriaRepositorio;

@SpringBootApplication
public class Proyecto1Application implements CommandLineRunner{


	public static void main(String[] args) {
		SpringApplication.run(Proyecto1Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		/*Categoria c = Categoria.builder()
				//.idCategoria(1L)
				.nombreCategoria("Cel2")
				.descripcionCategoria("Cel nuevos")
				.build();
		repository.save(c);*/
		System.out.println("hola sirve");
	}
	
	
}
