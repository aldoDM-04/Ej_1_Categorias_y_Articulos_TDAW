package com.ipn.mx.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ipn.mx.modelo.entidades.Categoria;
import com.ipn.mx.modelo.repositorios.CategoriaRepositorio;


@Service
public class CategoriasServiceImpl implements CategoriasService{
	@Autowired
	CategoriaRepositorio repository;

	@Override
	@Transactional(readOnly=true)
	public List<Categoria> findAll() {
		return (List<Categoria>) repository.findAll();
	}

	@Override
	public Categoria findById(Long id) {
		return repository.findById(id).orElse(null);
	}

	@Override
	public void deleteById(Long id) {
		repository.deleteById(id);
	}

	@Override
	public Categoria save(Categoria categoria) {
		return repository.save(categoria);
	}
	
	@Override
	public Categoria update(Categoria categoria) {
		return repository.save(categoria);
	}

}
